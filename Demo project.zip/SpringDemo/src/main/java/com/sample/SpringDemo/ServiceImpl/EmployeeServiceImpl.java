package com.sample.SpringDemo.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sample.SpringDemo.Service.EmployeeService;
import com.sample.SpringDemo.entity.Employee;
import com.sample.SpringDemo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	 private EmployeeRepository employeeRepository;
	
	@Override
	public Employee createEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	
	@Override
	public List<Employee> getAllEmployees(){
		return employeeRepository.findAll();
	}
	
	@Override
	public Employee updateEmployee(Long employeeId,Employee employeeDetails) {
		Optional<Employee> employeeOptional=employeeRepository.findById(employeeId);
		if(employeeOptional.isPresent()) {
			Employee employee=employeeOptional.get();
			employee.setEmployeeName(employeeDetails.getEmployeeName());
			employee.setEmail(employeeDetails.getEmail());
			return employeeRepository.save(employee);	
		}
		else {
			throw new RuntimeException("Record not found");
		}
	}
	
	@Override
	public Employee getEmployeeById(Long employeeId) {
		Optional<Employee> employeeOptional=employeeRepository.findById(employeeId);
		if(employeeOptional.isPresent()) {
			return employeeOptional.get() ;
		}
		else {
			throw new RuntimeException("Record not found");
		}
	}
	
	@Override
	public void deleteEmployee(Long employeeId) {
		Optional<Employee> employeeOptional=employeeRepository.findById(employeeId);
		if(employeeOptional.isPresent()) {
			employeeRepository.deleteById(employeeId);
			System.out.println("Employee record deleted successfully");
		}
		else {
			throw new RuntimeException("Record not found");
		}
	}

}
