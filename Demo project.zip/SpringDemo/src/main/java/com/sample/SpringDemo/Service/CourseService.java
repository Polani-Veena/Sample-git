package com.sample.SpringDemo.Service;

import java.util.List;

import com.sample.SpringDemo.entity.Course;

public interface CourseService {
	Course createCourse(Course course);
	List<Course> getAllCourses();
	Course getCourseById(String courseId);
	void deleteCourse(String courseId);
}
