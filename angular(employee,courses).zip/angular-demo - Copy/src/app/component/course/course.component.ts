import { Component, OnInit } from '@angular/core';
import { CourseService } from '../../service/course';
import { Course } from '../../models/course';

@Component({
  selector: 'app-course',
  standalone: false,
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  courses: Course[] = [];
  course: Course = { name: '', description: '', duration: '' };
  selectedCourseId: string | null = null;

  constructor(private courseService: CourseService) {}

  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses(): void {
    this.courseService.getAllCourses().subscribe(data => {
      this.courses = data;
    });
  }

  selectCourse(course: Course): void {
    this.selectedCourseId = course.id??null;
    this.course = { ...course };
  }

  saveCourse(): void {
    if (this.selectedCourseId) {
      this.courseService.updateCourse(this.selectedCourseId, this.course).subscribe(() => {
        this.loadCourses();
        this.resetForm();
      });
    } else {
      this.courseService.createCourse(this.course).subscribe(() => {
        this.loadCourses();
        this.resetForm();
      });
    }
  }

  deleteCourse(id: string): void {
    this.courseService.deleteCourse(id).subscribe(() => {
      this.loadCourses();
    });
  }

  resetForm(): void {
    this.course = { name: '', description: '', duration: '' };
    this.selectedCourseId = null;
  }
}

