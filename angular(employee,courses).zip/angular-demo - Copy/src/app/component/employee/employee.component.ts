import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../service/employee';
import { Employee } from '../../models/employee';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  imports: [FormsModule,CommonModule],
  styleUrls: ['./employee.component.css']  // <-- Fix: should be `styleUrls` (plural)
})
export class EmployeeComponent implements OnInit {
  employees: Employee[] = [];
  newEmployee: Employee = { name: '', role: '', email: '' };
  selectedEmployee: Employee | null = null;

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees(): void {
    this.employeeService.getEmployees().subscribe({
      next: (data) => this.employees = data,
      error: (err) => console.error('Error loading employees', err)
    });
  }

  addEmployee(): void {
    this.employeeService.createEmployee(this.newEmployee).subscribe({
      next: () => {
        this.loadEmployees();
        this.newEmployee = { name: '', role: '', email: '' };
      },
      error: (err) => console.error('Error creating employee', err)
    });
  }

  editEmployee(emp: Employee): void {
    this.selectedEmployee = { ...emp };
  }

  updateEmployee(): void {
    if (this.selectedEmployee?.id) {
      this.employeeService.updateEmployee(this.selectedEmployee.id, this.selectedEmployee).subscribe({
        next: () => {
          this.loadEmployees();
          this.selectedEmployee = null;
        },
        error: (err) => console.error('Error updating employee', err)
      });
    }
  }

  deleteEmployee(id: number): void {
    this.employeeService.deleteEmployee(id).subscribe({
      next: () => this.loadEmployees(),
      error: (err) => console.error('Error deleting employee', err)
    });
  }

  cancelEdit(): void {
    this.selectedEmployee = null;
  }
}
