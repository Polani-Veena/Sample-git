package com.sample.SpringDemo.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sample.SpringDemo.Service.CourseService;
import com.sample.SpringDemo.entity.Course;
import com.sample.SpringDemo.repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService{
	
	@Autowired
	private CourseRepository courseRepository;
	

	@Override
	public Course createCourse(Course course) {
		return courseRepository.save(course);
	}
	
	@Override
	public List<Course> getAllCourses(){
		return courseRepository.findAll();
	}
	
	@Override
	public Course getCourseById(String courseId) {
		Optional<Course> courseOptional=courseRepository.findById(courseId);
		if(courseOptional.isPresent()) {
			return courseOptional.get() ;
		}
		else {
			throw new RuntimeException("Record not found");
		}
	}
	
	@Override
	public void deleteCourse(String courseId) {
		Optional<Course> courseOptional=courseRepository.findById(courseId);
		if(courseOptional.isPresent()) {
			courseRepository.deleteById(courseId);
			System.out.println("Employee record deleted successfully");
		}
		else {
			throw new RuntimeException("Record not found");
		}
	}

}
