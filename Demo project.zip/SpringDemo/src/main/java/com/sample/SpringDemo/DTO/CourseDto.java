package com.sample.SpringDemo.DTO;

import lombok.Data;

@Data
public class CourseDto {
	private String courseId;
	private String courseName;
	private String description;

}
