package com.sample.SpringDemo.DTO;

import lombok.Data;

@Data
public class EmployeeDto {
	private Long employeeId;
	private String employeeName;
	private String email;

}
