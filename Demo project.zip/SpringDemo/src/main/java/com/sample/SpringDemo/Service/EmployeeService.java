package com.sample.SpringDemo.Service;

import java.util.List;

import com.sample.SpringDemo.entity.Employee;

public interface EmployeeService {
	
	Employee createEmployee(Employee employee);
	List<Employee> getAllEmployees();
	Employee updateEmployee(Long EmployeeId,Employee employeeDetails);
	Employee getEmployeeById(Long employeeId);
	void deleteEmployee(Long employeeId);

}
